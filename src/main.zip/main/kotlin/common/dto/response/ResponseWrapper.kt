package common.dto.response


class  ResponseWrapper(
    val success:Boolean = false,
    val data: Any? = null
)
