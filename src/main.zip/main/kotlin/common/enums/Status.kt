package common.enums

enum class Status {
    ACTIVE,
    NOT_ACTIVE,
    DELETED
}