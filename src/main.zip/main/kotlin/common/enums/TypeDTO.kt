package common.enums

enum class TypeDTO {
    DETAIL,

    SHORT,
    TEMPLATE
}