package common.enums

enum class TypeDtoReturn {
    DETAIL,
    SHORT,
    TEMPLATE
}