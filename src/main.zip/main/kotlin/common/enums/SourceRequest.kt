package common.enums

enum class SourceRequest {
    SITE,
    ANDROID,
    IOS,
}