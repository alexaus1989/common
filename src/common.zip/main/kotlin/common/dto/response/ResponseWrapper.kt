package traffus.blog.traffus_blog.base.dto.response


class  ResponseWrapper(
    val success:Boolean = false,
    val data: Any? = null
)
