package traffus.blog.traffus_blog.base.enums

enum class Status {
    ACTIVE,
    NOT_ACTIVE,
    DELETED
}