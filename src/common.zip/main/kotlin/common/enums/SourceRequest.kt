package traffus.blog.traffus_blog.base.enums

enum class SourceRequest {
    SITE,
    ANDROID,
    IOS,
}