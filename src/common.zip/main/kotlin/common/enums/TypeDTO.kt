package traffus.blog.traffus_blog.base.enums

enum class TypeDTO {
    DETAIL,

    SHORT,
    TEMPLATE
}