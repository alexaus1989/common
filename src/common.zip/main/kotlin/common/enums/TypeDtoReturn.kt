package traffus.blog.traffus_blog.base.enums

enum class TypeDtoReturn {
    DETAIL,
    SHORT,
    TEMPLATE
}