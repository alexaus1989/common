package traffus.blog.traffus_blog.base.config

import org.springframework.context.annotation.Configuration

@Configuration
class WebConfig {


}